"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/lambda/fix-generator/progress-publisher.js
var require_progress_publisher = __commonJS({
  "backend/lambda/fix-generator/progress-publisher.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || function(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) {
        for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
      }
      __setModuleDefault(result, mod);
      return result;
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ProgressPublisher = void 0;
    var client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
    var lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
    var client_apigatewaymanagementapi_1 = require("@aws-sdk/client-apigatewaymanagementapi");
    var dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
    var docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
    var CONNECTIONS_TABLE = process.env.CONNECTIONS_TABLE || "lensy-websocket-connections";
    var WEBSOCKET_API_ENDPOINT = process.env.WEBSOCKET_API_ENDPOINT;
    var ProgressPublisher2 = class {
      constructor(sessionId) {
        this.sessionId = sessionId;
        if (WEBSOCKET_API_ENDPOINT) {
          this.apiGatewayClient = new client_apigatewaymanagementapi_1.ApiGatewayManagementApiClient({
            endpoint: WEBSOCKET_API_ENDPOINT,
            region: process.env.AWS_REGION || "us-east-1"
          });
        }
      }
      async publish(message) {
        if (!this.apiGatewayClient) {
          console.log("WebSocket not configured, skipping progress update:", message);
          return;
        }
        try {
          const connections = await this.getSessionConnections();
          if (connections.length === 0) {
            console.log("No active connections for session:", this.sessionId);
            return;
          }
          const sendPromises = connections.map(async (connectionId) => {
            try {
              await this.apiGatewayClient.send(new client_apigatewaymanagementapi_1.PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: Buffer.from(JSON.stringify(message))
              }));
              console.log(`Sent progress to connection ${connectionId}:`, message.message);
            } catch (error) {
              if (error.statusCode === 410) {
                console.log("Stale connection, removing:", connectionId);
                await this.removeConnection(connectionId);
              } else {
                console.error("Error sending to connection:", connectionId, error);
              }
            }
          });
          await Promise.allSettled(sendPromises);
        } catch (error) {
          console.error("Error publishing progress:", error);
        }
      }
      async getSessionConnections() {
        try {
          const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: CONNECTIONS_TABLE,
            IndexName: "SessionIdIndex",
            KeyConditionExpression: "sessionId = :sessionId",
            ExpressionAttributeValues: {
              ":sessionId": this.sessionId
            }
          }));
          return result.Items?.map((item) => item.connectionId) || [];
        } catch (error) {
          console.error("Error querying connections:", error);
          return [];
        }
      }
      async removeConnection(connectionId) {
        try {
          const { DeleteCommand } = await Promise.resolve().then(() => __importStar(require("@aws-sdk/lib-dynamodb")));
          await docClient.send(new DeleteCommand({
            TableName: CONNECTIONS_TABLE,
            Key: { connectionId }
          }));
        } catch (error) {
          console.error("Error removing connection:", error);
        }
      }
      // Convenience methods for common message types
      async info(message, metadata) {
        await this.publish({
          type: "info",
          message,
          timestamp: Date.now(),
          metadata
        });
      }
      async success(message, metadata) {
        await this.publish({
          type: "success",
          message,
          timestamp: Date.now(),
          metadata
        });
      }
      async error(message, metadata) {
        await this.publish({
          type: "error",
          message,
          timestamp: Date.now(),
          metadata
        });
      }
      async progress(message, phase, metadata) {
        await this.publish({
          type: "progress",
          message,
          timestamp: Date.now(),
          phase,
          metadata
        });
      }
      async cacheHit(message, metadata) {
        await this.publish({
          type: "cache-hit",
          message,
          timestamp: Date.now(),
          metadata
        });
      }
      async cacheMiss(message, metadata) {
        await this.publish({
          type: "cache-miss",
          message,
          timestamp: Date.now(),
          metadata
        });
      }
    };
    exports2.ProgressPublisher = ProgressPublisher2;
  }
});

// backend/lambda/fix-generator/index.ts
var index_exports = {};
__export(index_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(index_exports);
var import_client_s3 = require("@aws-sdk/client-s3");
var import_client_bedrock_runtime = require("@aws-sdk/client-bedrock-runtime");
var import_progress_publisher = __toESM(require_progress_publisher());
var s3Client = new import_client_s3.S3Client({ region: process.env.AWS_REGION || "us-east-1" });
var bedrockClient = new import_client_bedrock_runtime.BedrockRuntimeClient({ region: process.env.AWS_REGION || "us-east-1" });
var handler = async (event) => {
  let input = event;
  if (event.body) {
    try {
      input = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    } catch (e) {
      console.warn("Could not parse event body, using event as is");
    }
  }
  const { sessionId, bucketName: eventBucket, modelId: eventModel, selectedRecommendations } = input;
  const bucketName = eventBucket || process.env.ANALYSIS_BUCKET;
  const modelId = eventModel || "us.anthropic.claude-3-5-sonnet-20241022-v2:0";
  console.log(`Starting Fix Generation for session: ${sessionId} (Bucket: ${bucketName})`);
  if (!sessionId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ success: false, message: "sessionId is required" })
    };
  }
  const progress = new import_progress_publisher.ProgressPublisher(sessionId);
  try {
    if (!bucketName) throw new Error("Bucket name is required (ANALYSIS_BUCKET env or bucketName payload)");
    await progress.progress("Loading analysis results...", "fix-generation");
    const contentKey = `sessions/${sessionId}/processed-content.json`;
    const contentStr = await getS3Object(bucketName, contentKey);
    const processedContent = JSON.parse(contentStr);
    const documentUrl = processedContent.url || "unknown-url";
    const resultsKey = `sessions/${sessionId}/dimension-results.json`;
    const resultsStr = await getS3Object(bucketName, resultsKey);
    const dimensionResults = JSON.parse(resultsStr);
    let issuesToFix = [];
    if (event.selectedRecommendations && event.selectedRecommendations.length > 0) {
      console.log(`Using ${event.selectedRecommendations.length} user-selected recommendations`);
      issuesToFix = event.selectedRecommendations;
    } else {
      console.log("No user-selected recommendations, using all findings from analysis");
      Object.values(dimensionResults).forEach((result) => {
        if (result.findings && Array.isArray(result.findings)) {
          issuesToFix.push(...result.findings);
        }
        if (result.recommendations && Array.isArray(result.recommendations)) {
          issuesToFix.push(...result.recommendations.map((r) => r.action));
        }
      });
    }
    issuesToFix = [...new Set(issuesToFix)];
    if (issuesToFix.length === 0) {
      await progress.success("No issues to fix.", { fixCount: 0 });
      return response(true, sessionId, 0, "No issues found to fix");
    }
    await progress.progress(`Generating fixes for ${issuesToFix.length} issues...`, "fix-generation");
    const fixes = await generateFixesWithBedrock(modelId, processedContent.markdownContent, issuesToFix, documentUrl);
    const fixSession = {
      sessionId,
      documentUrl,
      documentHash: processedContent.hash || (/* @__PURE__ */ new Date()).toISOString(),
      // Fallback
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      fixes: fixes.map((f) => ({ ...f, sessionId, status: "PROPOSED", generatedAt: (/* @__PURE__ */ new Date()).toISOString() })),
      summary: calculateSummary(fixes)
    };
    const fixesKey = `sessions/${sessionId}/fixes.json`;
    await s3Client.send(new import_client_s3.PutObjectCommand({
      Bucket: bucketName,
      Key: fixesKey,
      Body: JSON.stringify(fixSession, null, 2),
      ContentType: "application/json"
    }));
    await progress.success(`Generated ${fixes.length} fixes`, {
      fixCount: fixes.length,
      preview: fixes.slice(0, 3).map((f) => f.category)
    });
    const successBody = {
      success: true,
      fixSessionId: sessionId,
      fixCount: fixes.length,
      message: `Successfully generated ${fixes.length} fixes`
    };
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify(successBody)
    };
  } catch (error) {
    const errorMsg = error.Code === "NoSuchKey" ? `S3 Object Not Found: ${error.Key} in ${bucketName}` : error.message;
    console.error("Fix generation failed:", error);
    await progress.error(`Fix generation failed: ${errorMsg}`);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: false,
        fixSessionId: sessionId,
        fixCount: 0,
        message: errorMsg
      })
    };
  }
};
async function getS3Object(bucket, key) {
  const res = await s3Client.send(new import_client_s3.GetObjectCommand({ Bucket: bucket, Key: key }));
  return res.Body.transformToString();
}
function response(success, id, count, msg) {
  return { success, fixSessionId: id, fixCount: count, message: msg };
}
function calculateSummary(fixes) {
  const byCategory = {
    CODE_UPDATE: 0,
    LINK_FIX: 0,
    CONTENT_ADDITION: 0,
    VERSION_UPDATE: 0,
    FORMATTING_FIX: 0
  };
  let totalConfidence = 0;
  fixes.forEach((f) => {
    if (byCategory[f.category] !== void 0) byCategory[f.category]++;
    totalConfidence += f.confidence;
  });
  return {
    totalFixes: fixes.length,
    byCategory,
    averageConfidence: fixes.length > 0 ? Math.round(totalConfidence / fixes.length) : 0
  };
}
async function generateFixesWithBedrock(modelId, content, findings, url) {
  const prompt = `You are a technical documentation editor.
Your task is to generate precise, actionable fixes for the identified issues in the documentation.

DOCUMENT URL: ${url}

DOCUMENT CONTENT (Markdown):
\`\`\`markdown
${content.slice(0, 25e3)}
\`\`\`
(Content truncated if too long)

IDENTIFIED ISSUES:
${findings.map((f, i) => `${i + 1}. ${f}`).join("\n")}

INSTRUCTIONS:
For each issue that can be fixed by text/code modification, generate a "Fix Object".
- "originalContent": The EXACT text/code block from the document that needs changing (must match exactly to be findable).
- "proposedContent": The replacement text/code.
- "lineStart" / "lineEnd": Approximate line numbers (context).
- "category": One of [CODE_UPDATE, LINK_FIX, CONTENT_ADDITION, VERSION_UPDATE, FORMATTING_FIX].
- "confidence": 0-100 (how sure are you this is the correct fix).
- "rationale": Brief explanation.

If an issue is vague or cannot be fixed automatically, SKIP IT.
Output specific JSON only.

OUTPUT FORMAT:
Return a valid JSON array of objects. Do not wrap in markdown code blocks.
[
  {
    "id": "fix_1",
    "category": "CODE_UPDATE",
    "originalContent": "var x = 1;",
    "proposedContent": "const x = 1;",
    "lineStart": 10,
    "lineEnd": 10,
    "confidence": 95,
    "rationale": "Use const for immutability"
  }
]
`;
  const payload = {
    anthropic_version: "bedrock-2023-05-31",
    max_tokens: 4e3,
    messages: [{ role: "user", content: prompt }]
  };
  const command = new import_client_bedrock_runtime.InvokeModelCommand({
    modelId,
    contentType: "application/json",
    accept: "application/json",
    body: JSON.stringify(payload)
  });
  const response2 = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response2.body));
  const text = responseBody.content[0].text;
  try {
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) return [];
    const fixes = JSON.parse(jsonMatch[0]);
    return fixes.map((f, index) => ({
      id: `fix_${Date.now()}_${index}`,
      sessionId: "",
      // Filled by caller
      documentUrl: url,
      category: f.category || "FORMATTING_FIX",
      originalContent: f.originalContent || "",
      proposedContent: f.proposedContent || "",
      lineStart: f.lineStart || 0,
      lineEnd: f.lineEnd || 0,
      confidence: f.confidence || 0,
      rationale: f.rationale || "AI generated",
      status: "PROPOSED",
      generatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }));
  } catch (e) {
    console.error("Failed to parse AI fix response", e);
    console.log("Raw response:", text);
    throw new Error("AI response was not valid JSON");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
