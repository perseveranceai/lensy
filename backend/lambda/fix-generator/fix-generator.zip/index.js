"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
const progress_publisher_1 = require("./progress-publisher");
// --- Clients ---
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
const bedrockClient = new client_bedrock_runtime_1.BedrockRuntimeClient({ region: process.env.AWS_REGION || 'us-east-1' });
// --- Handler ---
const handler = async (event) => {
    const { sessionId } = event;
    const bucketName = event.bucketName || process.env.ANALYSIS_BUCKET;
    const modelId = event.modelId || 'anthropic.claude-3-5-sonnet-20240620-v1:0'; // Default to Sonnet 3.5
    console.log(`Starting Fix Generation for session: ${sessionId}`);
    const progress = new progress_publisher_1.ProgressPublisher(sessionId);
    try {
        if (!bucketName)
            throw new Error('Bucket name is required');
        // 1. Load Data from S3
        await progress.progress('Loading analysis results...', 'fix-generation');
        // Load Processed Content
        const contentKey = `sessions/${sessionId}/processed-content.json`;
        const contentStr = await getS3Object(bucketName, contentKey);
        const processedContent = JSON.parse(contentStr);
        const documentUrl = processedContent.url || 'unknown-url';
        // Load Findings (Dimension Results)
        const resultsKey = `sessions/${sessionId}/dimension-results.json`;
        const resultsStr = await getS3Object(bucketName, resultsKey);
        const dimensionResults = JSON.parse(resultsStr);
        // Aggregate findings
        const allFindings = [];
        Object.values(dimensionResults).forEach((result) => {
            if (result.findings && Array.isArray(result.findings)) {
                allFindings.push(...result.findings);
            }
        });
        if (allFindings.length === 0) {
            await progress.success('No issues to fix.', { fixCount: 0 });
            return response(true, sessionId, 0, 'No issues found to fix');
        }
        // 2. Generate Fixes with Bedrock
        await progress.progress(`Generating fixes for ${allFindings.length} issues...`, 'fix-generation');
        const fixes = await generateFixesWithBedrock(modelId, processedContent.markdownContent, allFindings, documentUrl);
        // 3. Create Fix Session
        const fixSession = {
            sessionId,
            documentUrl,
            documentHash: processedContent.hash || new Date().toISOString(), // Fallback
            createdAt: new Date().toISOString(),
            fixes: fixes.map(f => ({ ...f, sessionId, status: 'PROPOSED', generatedAt: new Date().toISOString() })),
            summary: calculateSummary(fixes)
        };
        // 4. Save to S3
        const fixesKey = `sessions/${sessionId}/fixes.json`;
        await s3Client.send(new client_s3_1.PutObjectCommand({
            Bucket: bucketName,
            Key: fixesKey,
            Body: JSON.stringify(fixSession, null, 2),
            ContentType: 'application/json'
        }));
        await progress.success(`Generated ${fixes.length} fixes`, {
            fixCount: fixes.length,
            preview: fixes.slice(0, 3).map(f => f.category)
        });
        return response(true, sessionId, fixes.length, `Successfully generated ${fixes.length} fixes`);
    }
    catch (error) {
        console.error('Fix generation failed:', error);
        await progress.error(`Fix generation failed: ${error.message}`);
        return {
            success: false,
            fixSessionId: sessionId,
            fixCount: 0,
            message: error.message
        };
    }
};
exports.handler = handler;
// --- Helpers ---
async function getS3Object(bucket, key) {
    const res = await s3Client.send(new client_s3_1.GetObjectCommand({ Bucket: bucket, Key: key }));
    return res.Body.transformToString();
}
function response(success, id, count, msg) {
    return { success, fixSessionId: id, fixCount: count, message: msg };
}
function calculateSummary(fixes) {
    const byCategory = {
        CODE_UPDATE: 0, LINK_FIX: 0, CONTENT_ADDITION: 0, VERSION_UPDATE: 0, FORMATTING_FIX: 0
    };
    let totalConfidence = 0;
    fixes.forEach(f => {
        if (byCategory[f.category] !== undefined)
            byCategory[f.category]++;
        totalConfidence += f.confidence;
    });
    return {
        totalFixes: fixes.length,
        byCategory,
        averageConfidence: fixes.length > 0 ? Math.round(totalConfidence / fixes.length) : 0
    };
}
// --- AI Logic ---
async function generateFixesWithBedrock(modelId, content, findings, url) {
    // Construct Prompt
    const prompt = `You are a technical documentation editor.
Your task is to generate precise, actionable fixes for the identified issues in the documentation.

DOCUMENT URL: ${url}

DOCUMENT CONTENT (Markdown):
\`\`\`markdown
${content.slice(0, 25000)}
\`\`\`
(Content truncated if too long)

IDENTIFIED ISSUES:
${findings.map((f, i) => `${i + 1}. ${f}`).join('\n')}

INSTRUCTIONS:
For each issue that can be fixed by text/code modification, generate a "Fix Object".
- "originalContent": The EXACT text/code block from the document that needs changing (must match exactly to be findable).
- "proposedContent": The replacement text/code.
- "lineStart" / "lineEnd": Approximate line numbers (context).
- "category": One of [CODE_UPDATE, LINK_FIX, CONTENT_ADDITION, VERSION_UPDATE, FORMATTING_FIX].
- "confidence": 0-100 (how sure are you this is the correct fix).
- "rationale": Brief explanation.

If an issue is vague or cannot be fixed automatically, SKIP IT.
Output specific JSON only.

OUTPUT FORMAT:
Return a valid JSON array of objects. Do not wrap in markdown code blocks.
[
  {
    "id": "fix_1",
    "category": "CODE_UPDATE",
    "originalContent": "var x = 1;",
    "proposedContent": "const x = 1;",
    "lineStart": 10,
    "lineEnd": 10,
    "confidence": 95,
    "rationale": "Use const for immutability"
  }
]
`;
    // Call Bedrock (Claude 3.5 Sonnet payload)
    const payload = {
        anthropic_version: "bedrock-2023-05-31",
        max_tokens: 4000,
        messages: [{ role: "user", content: prompt }]
    };
    const command = new client_bedrock_runtime_1.InvokeModelCommand({
        modelId,
        contentType: 'application/json',
        accept: 'application/json',
        body: JSON.stringify(payload)
    });
    const response = await bedrockClient.send(command);
    const responseBody = JSON.parse(new TextDecoder().decode(response.body));
    const text = responseBody.content[0].text;
    // Parse JSON
    try {
        const jsonMatch = text.match(/\[[\s\S]*\]/);
        if (!jsonMatch)
            return [];
        const fixes = JSON.parse(jsonMatch[0]);
        // Basic validation/sanitization
        return fixes.map((f, index) => ({
            id: `fix_${Date.now()}_${index}`,
            sessionId: '', // Filled by caller
            documentUrl: url,
            category: (f.category || 'FORMATTING_FIX'),
            originalContent: f.originalContent || '',
            proposedContent: f.proposedContent || '',
            lineStart: f.lineStart || 0,
            lineEnd: f.lineEnd || 0,
            confidence: f.confidence || 0,
            rationale: f.rationale || 'AI generated',
            status: 'PROPOSED',
            generatedAt: new Date().toISOString()
        }));
    }
    catch (e) {
        console.error("Failed to parse AI fix response", e);
        console.log("Raw response:", text);
        throw new Error("AI response was not valid JSON");
    }
}
